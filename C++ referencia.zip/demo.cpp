﻿#include <iostream>
#include "SecSys.h"
#include "Sensors.h"
#include "SysFuncCall.h"
#include "Systemlog.h"
#include "memtrace.h"

/*Demo tesztprogram*/

int main()
{

	/*Szenzorok generálása-> 3 szoba van és mindegyikben 1-1 típusu szenzor, ezeknek adatai a security log vezetéséhez kell majd*/

	//1 szoba
	Msensor M1('M', 1);
	M1.activate();
	Hsensor H1('H', 1);
	H1.activate();
	Ksensor K1('K', 1);
	K1.activate();

	//2 szoba
	Msensor M2('M', 2);
	M2.activate();
	Hsensor H2('H', 2);
	H2.activate();
	Ksensor K2('K', 2);
	K2.activate();

	/*Teszteset indítása*/
	std::cout
		<< "////////////////////////////////////////////////" << std::endl
		<< "//  **********SECURITY SYSTEM 2022**********  //" << std::endl
		<< "//  *********NHF::NAGY ROLAND VIKTOR********  //" << std::endl
		<< "////////////////////////////////////////////////" << std::endl
		<< "\n"
		<< "To initiate system please set disarm code and timer, and then select wich systems to activate" << std::endl
		<< "\n"
		<< "Security Code: 12345";		
	CodePanel Panel(12345); //megadjuk a kódot amivel majd deaktiváljuk
	std::cout
		<< "\n"
		<< "Timer(sec): 120";
	Timer Countdown(120); //megadjuk az időt amiddig él a rendszer
	std::cout << "\n"
		<< "1.)StandBy" << std::endl
		<< "2.)Arm" << std::endl
		<< "3.)Stay" << std::endl
		<< "select mode: 1 ";
	std::cout << "StandBy selected" << std::endl;

	bool Arm = false; //Minden érzékelő aktív -> false
	bool Stay = false; //Csak a mozgásérzékelő inaktív -> false

	Siren Alarm; //Sziréna generálása
	Switch Swtch; //Kapcsolók generálása
	Systemlog Log(20); //Biztonsági napló generélása

	std::cout << "System activated " << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "Room 1 door opened" << std::endl;
	doortest(K1, Alarm, Swtch, Arm, Stay); //ajtó nyitás/zárás
	Log.add(&K1); //A System-hez hozzáadunk egy új bejegyzést
	Countdown.sec(1); //x időt vesz igénybe a művelet
	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "Room 1 door closed" << std::endl;
	doortest(K1, Alarm, Swtch, Arm, Stay);
	Log.add(&K1);
	Countdown.sec(1);
	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "movement in room 1" << std::endl;
	M1.move(20); //ennyi időt mozog
	movementtest(M1, Alarm, Swtch, Arm, Stay); //mozgás
	Log.add(&M1);
	Countdown.sec(20);
	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "Room 2 door opened" << std::endl;
	doortest(K2, Alarm, Swtch, Arm, Stay);
	Log.add(&K2);
	Countdown.sec(1);
	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "Room 2 door closed" << std::endl;
	doortest(K2, Alarm, Swtch, Arm, Stay);
	Log.add(&K2);
	Countdown.sec(1);
	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "movement in room 2" << std::endl;
	M1.move(30);
	movementtest(M2, Alarm, Swtch, Arm, Stay);
	Log.add(&M2);
	Countdown.sec(30);
	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "heat in room" << std::endl;
	H2.heat(40); //hőfok a szobában
	heattest(H2, Alarm, Swtch); //hőérzékelő
	Log.add(&H2);
	Countdown.sec(1);
	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "passing time" << std::endl;
	Countdown.sec(30);
	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "heat in room" << std::endl;
	H2.heat(74);
	heattest(H2, Alarm, Swtch);
	Log.add(&H2);
	Countdown.sec(1);
	std::cout << "\n"
		<< "Security Log:"
		<< "\n";
	
	Log.writeall();
	M1.deactivate();
	H1.deactivate();
	K1.deactivate();
	M2.deactivate();
	H2.deactivate();
	K2.deactivate();
	

	/*Új teszteset*/
	std::cout << "\n"
		<< "NEW TEST: ARM" << std::endl
		<< "\n"
		<< "To initiate system please set disarm code and timer, and then select wich systems to activate" << std::endl
		<< "\n"
		<< "Security Code: 12345";
	std::cout
		<< "\n"
		<< "Timer(sec): 30";
	Countdown.settimer(30); //megadjuk az időt amiddig él a rendszer
	std::cout << "\n"
		<< "1.)StandBy" << std::endl
		<< "2.)Arm" << std::endl
		<< "3.)Stay" << std::endl
		<< "select mode: 2 ";
	std::cout << "Arm selected" << std::endl;
	 //Csak a mozgás hőérzékelő aktív -> false
	Arm = true; //Minden érzékelő aktív -> true
	Stay = false; //Csak a mozgásérzékelő inaktív -> false

	/*Erre az esetre elég csak 1 szobát aktiválni*/
	M1.activate();
	H1.activate();
	K1.activate();
	Systemlog Log2(5);

	std::cout << "System activated " << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "Room 1 door opened" << std::endl;
	doortest(K1, Alarm, Swtch, Arm, Stay);
	Log2.add(&K1);
	Countdown.sec(1);
	std::cout << Countdown.gettimer() << "s remaining" << std::endl;

	std::cout << "\n"
		<< "Security Log:"
		<< "\n";
	Log2.writeall();

	M1.deactivate();
	H1.deactivate();
	K1.deactivate();


	std::cout << "\n"
		<< "NEW TEST: STAY" << std::endl
		<< "\n"
		<< "To initiate system please set disarm code and timer, and then select wich systems to activate" << std::endl
		<< "\n"
		<< "Security Code: 12345";
	std::cout
		<< "\n"
		<< "Timer(sec): 30";
	Countdown.settimer(30); //megadjuk az időt amiddig él a rendszer
	std::cout << "\n"
		<< "1.)StandBy" << std::endl
		<< "2.)Arm" << std::endl
		<< "3.)Stay" << std::endl
		<< "select mode: 3 ";
	std::cout << "Stay selected" << std::endl;
	 //Csak a mozgás hőérzékelő aktív -> false
	Arm = false; //Minden érzékelő aktív -> true
	Stay = true; //Csak a mozgásérzékelő inaktív -> false

	/*Erre az esetre elég csak 1 szobát aktiválni, ott is csak az ajtót*/
	K1.activate();
	Systemlog Log3(5);

	std::cout << "System activated " << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "movement in room 1" << std::endl;
	M1.move(20);
	movementtest(M1, Alarm, Swtch, Arm, Stay);
	Log3.add(&M1);
	Countdown.sec(20);
	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "Room 1 door opened" << std::endl;
	doortest(K1, Alarm, Swtch, Arm, Stay);
	Log3.add(&K1);
	Countdown.sec(1);

	std::cout << "\n"
		<< "Security Log:"
		<< "\n";
	Log3.writeall();

	K1.deactivate();



	/*Itt csak az időzítőt teszteljük*/
	std::cout << "\n"
		<< "NEW TEST: TIMER" << std::endl
		<< "\n"
		<< "To initiate system please set disarm code and timer, and then select wich systems to activate" << std::endl
		<< "\n"
		<< "Security Code: 12345";
	std::cout
		<< "\n"
		<< "Timer(sec): 10";
	Countdown.settimer(10); //megadjuk az időt amiddig él a rendszer
	std::cout << "\n"
		<< "1.)StandBy" << std::endl
		<< "2.)Arm" << std::endl
		<< "3.)Stay" << std::endl
		<< "select mode: 2 ";
	std::cout << "Arm selected" << std::endl;
	//Csak a mozgás hőérzékelő aktív -> false
	Arm = false; //Minden érzékelő aktív -> false
	Stay = true; //Csak a mozgásérzékelő inaktív -> true

	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "passing time" << std::endl;
	Countdown.sec(10);
	std::cout << "No SecLog";


	/*Itt csak a kód panelt teszteljük (rossz kód)*/
	std::cout << "\n"
		<< "NEW TEST: CODE FALSE" << std::endl
		<< "\n"
		<< "To initiate system please set disarm code and timer, and then select wich systems to activate" << std::endl
		<< "\n"
		<< "Security Code: 12345";
	std::cout
		<< "\n"
		<< "Timer(sec): 10";
	Countdown.settimer(10); //megadjuk az időt amiddig él a rendszer
	std::cout << "\n"
		<< "1.)StandBy" << std::endl
		<< "2.)Arm" << std::endl
		<< "3.)Stay" << std::endl
		<< "select mode: 2 ";
	std::cout << "Arm selected" << std::endl;
	//Csak a mozgás hőérzékelő aktív -> false
	Arm = false; //Minden érzékelő aktív -> true
	Stay = true; //Csak a mozgásérzékelő inaktív -> false

	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "trying false code: 11111" << std::endl;
	if (SysDeact(11111, Panel)) { //countdown if: ha jó simán kilép, ha nem riaszt és kilép
		std::cout << "System successfully deactivated, all systems shutting down" << std::endl; 
		Countdown.sec(Countdown.timer()); //rendszer kikapcsolása, timer végigér
	}
	else {
		Alarm.alarmc();
		Countdown.sec(Countdown.timer());
	}
	std::cout << "No SecLog";

	/*Itt csak a kód panelt teszteljük (helyes kód)*/
	std::cout << "\n"
		<< "NEW TEST: CODE TRUE" << std::endl
		<< "\n"
		<< "To initiate system please set disarm code and timer, and then select wich systems to activate" << std::endl
		<< "\n"
		<< "Security Code: 12345";
	std::cout
		<< "\n"
		<< "Timer(sec): 10";
	Countdown.settimer(10); //megadjuk az időt amiddig él a rendszer
	std::cout << "\n"
		<< "1.)StandBy" << std::endl
		<< "2.)Arm" << std::endl
		<< "3.)Stay" << std::endl
		<< "select mode: 2 ";
	std::cout << "Arm selected" << std::endl;
	//Csak a mozgás hőérzékelő aktív -> false
	Arm = false; //Minden érzékelő aktív -> true
	Stay = true; //Csak a mozgásérzékelő inaktív -> false

	std::cout << Countdown.gettimer() << "s remaining" << std::endl;
	std::cout << "trying true code: 12345" << std::endl;
	if (SysDeact(12345, Panel)) {
		std::cout << "System successfully deactivated, all systems shutting down" << std::endl;
		Countdown.sec(Countdown.timer());
	}
	else {
		Alarm.alarmc();
		Countdown.sec(Countdown.timer());
	}
	std::cout << "No SecLog";
	std::cout << "\n";

return 0;
}