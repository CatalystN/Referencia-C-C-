#include "SecSys.h"
#include <iostream>
#include "memtrace.h"

//Siren class
void Siren::alarmc() const {
	std::cout << "################################## ALARM: CODE INTRUSION DETECTED ##################################" << std::endl;
}

void Siren::alarms() const {
	std::cout << "################################## ALARM: SENSOR ACTIVATON DETECTED ################################" << std::endl;
}

//CodePanel class
bool CodePanel::deact(int cod) {
	if (code == cod)
		return true;
	else
		return false;
}

//Timer class

void Timer::sec(int number) {
	time -= number;
}

bool Timer::timer() const {
	if (time <= 0)
		return false;
	else
		return true;
}

int Timer::gettimer() const {
	return time;
}

void Timer::settimer(int time) { this->time = time; }

//Switch class
bool Switch::AND(Sensor& s, bool mode) {
	if (s.alert() && mode)
		return true;
	else
		return false;
}

bool Switch::OR(bool m1, bool m2) {
	if (m1 || m2)
		return true;
	else
		return false;
}
