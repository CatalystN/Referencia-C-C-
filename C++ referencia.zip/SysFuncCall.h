﻿#ifndef TEST_H
#define TEST_H

void doortest(Ksensor& k, Siren& Alarm, Switch& swtch, bool mode1, bool mode2); //az ajtó nyitására elindítja a riasztót ha az aktív
void heattest(Hsensor& h, Siren& Alarm, Switch& swtch); //az hőérzékelő aktiválására elindítja a riasztót ha az aktív
void movementtest(Msensor& m, Siren& Alarm, Switch& swtch, bool mode1, bool mode2); //az mozgásérzékelő aktiválására elindítja a riasztót ha az aktív
bool SysDeact(int code, CodePanel& panel); //deaktiválja a rendszert code alapján

#endif
