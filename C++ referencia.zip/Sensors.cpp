#include "Sensors.h"
#include <iostream>
#include "memtrace.h"


//Sensor class
void Sensor::activate() {
	active = true;
}

void Sensor::deactivate() {
	active = false;
}

bool Sensor::alert() {
	return active;
}

void Sensor::show() const {
	std::cout << "room: " << area << std::endl << "type: " << type << std::endl;
}

//Ksensor class
void Ksensor::openclose() {
	if (closed)
		closed = false;
	else
		closed = true;
}

bool Ksensor::getstat() const {
	return closed;
}

//Hsensor class
void Hsensor::heat(double h) {
	temp = h;
}

double Hsensor::getstat() const {
	return temp;
}

//Msensor class
void Msensor::move(int time) {
	movement = time;
}

int Msensor::getstat() const {
	return movement;
}