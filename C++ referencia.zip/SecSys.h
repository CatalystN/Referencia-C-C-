﻿#ifndef SECSYS_H
#define SECSYS_H
#include<iostream>
#include "Sensors.h"

class Siren {
public:
	Siren() {}
	void alarms() const; //sziréna elindul ha egy szenzor jelez
	void alarmc() const; //sziréna elindul ha rossz a kód
};

//CodePanel osztály
class CodePanel {
	int code; //a rendszert deaktiváló kód
public:
	CodePanel(int code) :code(code) {}
	bool deact(int cod); //deaktiválja a rendszert
};

//Timer osztály
class Timer {
	int time; //hátralévő idő
public:
	Timer(int time) :time(time) {};
	void sec(int time); //kivonja a time-ból a megadott időt
	bool timer() const; //megkapja az időzítő állapotát
	int gettimer() const; //lekérdezi a hátralévő időt
	void settimer(int time); //beállít egy új időt
};


//Kapcsoló osztály
class Switch {
public:
	bool AND(Sensor& s, bool mode); //AND kapu
	bool OR(bool m1, bool m2); //OR kapu
};

#endif // !SECSYS_H

