#include "Sensors.h"
#include "SecSys.h"
#include "memtrace.h"
#include "Systemlog.h"

void Systemlog::add(Sensor* ujdata) {
	data[siz++] = ujdata;
}

void Systemlog::writeall() const {
	for (int i = 0; i < siz; i++) {
		std::cout << "\n";
		data[i]->show();
	}
}

Systemlog::~Systemlog() {
	delete[] data;
}