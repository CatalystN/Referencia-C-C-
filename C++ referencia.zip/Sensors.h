﻿#include <ostream>
#ifndef SENSORS_H
#define SENSORS_H

 //Szenzor osztély
class Sensor {
	bool active; //be van e kapcsolva a szenzor
protected:
	int area; //szenzor helye
	char type; //szenzor típusa(M-mozgás, H-hő, K-kontakt)
public:
	Sensor() :active(false), area('0'), type(0){};
	Sensor(char type, int area) :active(false), area(area), type(type) {};
	void activate(); //szenzor aktiválása -> active:true
	void deactivate(); //szenzor deaktiválása -> active:false
	bool alert(); //szenzor jelet küld ha active == on
	void show() const; //kiírja az összes adatát
};

class Msensor : public Sensor {
	int movement; //mozgást ideje
public:
	Msensor(char type, int area) :Sensor(type, area), movement(0) {}
	void move(int time); //meddig van mozgás
	int getstat() const; //lekérdezi az állapotot
};

class Hsensor : public Sensor {
	double temp;
public:
	Hsensor(char type, int area) : Sensor(type, area), temp(21) {}
	void heat(double temp); //hány fok van az adott szobában
	double getstat() const; //lekérdezi az állapotot
};

class Ksensor : public Sensor {
	bool closed;
public:
	Ksensor(char type, int area) :Sensor(type, area), closed(true) {}
	void openclose(); //ajtónyitás/zárás
	bool getstat() const; //lekérdezi az állapotot
};


#endif // !SENSORS_H


