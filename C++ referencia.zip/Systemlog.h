#ifndef SYSTEMLOG_H
#define SYSTEMLOG_H
#include "Sensors.h"
#include "SecSys.h"
#include "memtrace.h"

//heterog�n kollekci�, Systemlog oszt�ly

class Systemlog {
	int siz;
	Sensor** data;
public:
	Systemlog(int cap) :siz(0), data(new Sensor* [cap]) {} //default konstruktor
	void add(Sensor* ujdata); //�j adatot ad hozz�
	void writeall() const; //ki�rja az �sszes t�rolt adatot
	~Systemlog(); //destruktor, felszabad�tja a t�rolt adatot
};
	
#endif // !SYSTEMLOG_H
