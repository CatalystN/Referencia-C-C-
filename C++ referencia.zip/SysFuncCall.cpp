#include "SecSys.h"
#include "Sensors.h"
#include "SysFuncCall.h"
#include "memtrace.h"

void doortest(Ksensor& k, Siren& Alarm, Switch& swtch, bool mode1, bool mode2) {
	if (swtch.AND(k, swtch.OR(mode1, mode2)))
		Alarm.alarms();
	else
		if (k.getstat()) {
			std::cout << "door opened" << std::endl;
			k.openclose();
		}
	else
		if (k.getstat() == false) {
			std::cout << "door closed" << std::endl;
			k.openclose();
		}
}

void heattest(Hsensor& h, Siren& Alarm, Switch& swtch) {
	if (swtch.AND(h, (h.getstat() >= 70) == true))
		Alarm.alarms();
	else
		std::cout << "temp is below 70 -> " << h.getstat() << std::endl;
}

void movementtest(Msensor& m, Siren& Alarm, Switch& swtch, bool mode1, bool mode2) {
	if (swtch.AND(m, swtch.OR(mode1, mode2)))
		Alarm.alarms();
	else
		std::cout << "alarms not active, movement for " << m.getstat() << " seconds" << std::endl;
}

bool SysDeact(int code, CodePanel& panel) {
	if (panel.deact(code)) {
		std::cout << "System deactivated" << std::endl;
		return true;
	}
	else
		return false;
}
